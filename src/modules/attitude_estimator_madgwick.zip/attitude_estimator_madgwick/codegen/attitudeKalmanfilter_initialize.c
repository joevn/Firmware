/*
 * attitudeKalmanfilter_initialize.c
 *
 * Code generation for function 'attitudeKalmanfilter_initialize'
 *
 * C source code generated on: Sat Jan 19 15:25:29 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "attitudeKalmanfilter.h"
#include "attitudeKalmanfilter_initialize.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
void attitudeKalmanfilter_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/* End of code generation (attitudeKalmanfilter_initialize.c) */
