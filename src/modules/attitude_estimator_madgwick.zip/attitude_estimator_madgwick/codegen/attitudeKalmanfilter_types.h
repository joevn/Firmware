/*
 * attitudeKalmanfilter_types.h
 *
 * Code generation for function 'attitudeKalmanfilter'
 *
 * C source code generated on: Sat Jan 19 15:25:29 2013
 *
 */

#ifndef __ATTITUDEKALMANFILTER_TYPES_H__
#define __ATTITUDEKALMANFILTER_TYPES_H__

/* Type Definitions */

#endif
/* End of code generation (attitudeKalmanfilter_types.h) */
