/*
 * attitudeKalmanfilter_terminate.c
 *
 * Code generation for function 'attitudeKalmanfilter_terminate'
 *
 * C source code generated on: Sat Jan 19 15:25:29 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "attitudeKalmanfilter.h"
#include "attitudeKalmanfilter_terminate.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
void attitudeKalmanfilter_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (attitudeKalmanfilter_terminate.c) */
